@echo off
REM Mr. A. Maganlal
REM Computer Science 3B 2016 - 2025
REM This batch file is setup to be more robust than previous versions
setlocal enabledelayedexpansion
set PROJNAME=%~1
set DLLNAME=%~2
set ERRMSG=

if "%PROJNAME%"=="" GOTO USAGE
if "%DLLNAME%"=="" GOTO USAGE
GOTO CLEAN

:USAGE
echo %PROJNAME% %DLLNAME%
echo [36mUsage: createdll [asmFileNameWithoutExtension] [dllFileNameWithoutExtension]
echo All asm and def files must be in the 'src' folder![0m
goto END

:CLEAN
echo [36m~~~ Cleaning project ~~~[0m
DEL /S %DLLNAME%.dll %DLLNAME%.lib %DLLNAME%.exp %PROJNAME%.lst %PROJNAME%.obj
IF /I "%ERRORLEVEL%" NEQ "0" (
    set ERRMSG=ERROR Cleaning
    GOTO ERROR
)

:ASSEMBLE
echo [36m~~~ Assembling project ~~~[0m
.\assembler\ml.exe /nologo /coff /Fl /Fo .\bin\%PROJNAME%.obj /Zi /c .\src\%PROJNAME%.asm
IF /I "%ERRORLEVEL%" NEQ "0" (
    set ERRMSG=Assembling ERROR. Check error messages!
    move %PROJNAME%.lst .\bin\%PROJNAME%.lst > NUL
    GOTO ERROR
)
REM Workaround for lst error
move %PROJNAME%.lst .\bin\%PROJNAME%.lst > NUL

:LINK
echo [36m~~~ Linking project ~~~[0m
.\assembler\link.exe /nologo /dll /subsystem:console /def:src\%DLLNAME%.def /out:bin\%DLLNAME%.dll .\bin\%PROJNAME%.obj .\assembler\kernel32.lib .\assembler\io.lib
IF /I "%ERRORLEVEL%" NEQ "0" (
    set ERRMSG=Linking ERROR. Check error messages!
    GOTO ERROR
)

:RUN
echo [36m~~~ Running project ~~~[0m
bin\%DLLNAME%.exe
IF /I "%ERRORLEVEL%" NEQ "0" (
    set ERRMSG="Running"
    GOTO ERROR
)
GOTO END

:ERROR
echo [31;1m### An error has occured ###[0m
echo [31;1m%ERRMSG%[0m

:END
echo [36m~~~ End ~~~[0m
