;	Update all of this information to reflect your own details and the practical
;	Author:	MBOYI DN 222019179
;	PE3 DLL starter file
.386
.MODEL FLAT, stdcall
.STACK 4096

.CODE

; LibMain function tests which action is currently beign performed
; The function returns if the DLL is loaded correctly or not.
; We avoid the complex logic here for simplicity.
LibMain proc instance:DWORD, reason:DWORD, unused:DWORD
	mov eax, 1
  ret
LibMain ENDP

solarRatio PROC NEAR32
    PUSH EBP
    MOV EBP, ESP
    
    ; Multiply in the registers, store them into memory, then load them as a float
    MOV EAX, [EBP+8] ; coverage
    IMUL EAX, [EBP+12] ; coverage * solarOutput
    
    PUSH EAX ; Store product on stack
    FILD DWORD PTR [ESP]      
    
    MOV EAX, [EBP+16]         
    PUSH EAX

	  ; Load capacity as float
    FILD DWORD PTR [ESP]
	    
    ; Divide
    FDIVP ST(1), ST(0)        
	; Clean both of our temporary values
    ADD ESP, 8                
    POP EBP
    RET 12
solarRatio ENDP

end LibMain
